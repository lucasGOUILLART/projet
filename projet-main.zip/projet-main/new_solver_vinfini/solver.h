#pragma once
#include "game.h"
#include "file.h"

char* solver(Game* g);
char* concatener(const char* chaine1, const char* chaine2);